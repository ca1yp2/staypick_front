import React from 'react'

const MyPage = () => {
  return (
    <div>MyPage</div>
  )
}

export default MyPage