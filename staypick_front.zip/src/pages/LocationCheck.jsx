import React from 'react'

const LocationCheck = () => {
  return (
    <div>LocationCheck</div>
  )
}

export default LocationCheck